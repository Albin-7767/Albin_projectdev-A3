﻿namespace Inclass_1
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resultbox = new System.Windows.Forms.TextBox();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnsub = new System.Windows.Forms.Button();
            this.btneight = new System.Windows.Forms.Button();
            this.btnseven = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.btnclearc = new System.Windows.Forms.Button();
            this.btnequal = new System.Windows.Forms.Button();
            this.btnone = new System.Windows.Forms.Button();
            this.btnmulti = new System.Windows.Forms.Button();
            this.btnsix = new System.Windows.Forms.Button();
            this.btnfive = new System.Windows.Forms.Button();
            this.btnfour = new System.Windows.Forms.Button();
            this.btnnine = new System.Windows.Forms.Button();
            this.btndot = new System.Windows.Forms.Button();
            this.btnzero = new System.Windows.Forms.Button();
            this.btndivided = new System.Windows.Forms.Button();
            this.btnthree = new System.Windows.Forms.Button();
            this.btntwo = new System.Windows.Forms.Button();
            this.label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // resultbox
            // 
            this.resultbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultbox.Location = new System.Drawing.Point(87, 115);
            this.resultbox.Name = "resultbox";
            this.resultbox.Size = new System.Drawing.Size(246, 22);
            this.resultbox.TabIndex = 0;
            this.resultbox.Text = "0";
            this.resultbox.TextChanged += new System.EventHandler(this.resultbox_TextChanged);
            // 
            // btnclear
            // 
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.Location = new System.Drawing.Point(87, 181);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(40, 23);
            this.btnclear.TabIndex = 1;
            this.btnclear.Text = "C";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnsub
            // 
            this.btnsub.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsub.Location = new System.Drawing.Point(293, 222);
            this.btnsub.Name = "btnsub";
            this.btnsub.Size = new System.Drawing.Size(40, 23);
            this.btnsub.TabIndex = 2;
            this.btnsub.Text = "-";
            this.btnsub.UseVisualStyleBackColor = true;
            this.btnsub.Click += new System.EventHandler(this.btnsub_Click);
            // 
            // btneight
            // 
            this.btneight.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btneight.Location = new System.Drawing.Point(143, 222);
            this.btneight.Name = "btneight";
            this.btneight.Size = new System.Drawing.Size(40, 23);
            this.btneight.TabIndex = 3;
            this.btneight.Text = "8";
            this.btneight.UseVisualStyleBackColor = true;
            this.btneight.Click += new System.EventHandler(this.btneight_Click);
            // 
            // btnseven
            // 
            this.btnseven.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnseven.Location = new System.Drawing.Point(87, 222);
            this.btnseven.Name = "btnseven";
            this.btnseven.Size = new System.Drawing.Size(40, 23);
            this.btnseven.TabIndex = 4;
            this.btnseven.Text = "7";
            this.btnseven.UseVisualStyleBackColor = true;
            this.btnseven.Click += new System.EventHandler(this.btnseven_Click);
            // 
            // btnadd
            // 
            this.btnadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.Location = new System.Drawing.Point(293, 181);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(40, 23);
            this.btnadd.TabIndex = 5;
            this.btnadd.Text = "+";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // btnclearc
            // 
            this.btnclearc.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclearc.Location = new System.Drawing.Point(143, 181);
            this.btnclearc.Name = "btnclearc";
            this.btnclearc.Size = new System.Drawing.Size(65, 23);
            this.btnclearc.TabIndex = 6;
            this.btnclearc.Text = "CE";
            this.btnclearc.UseVisualStyleBackColor = true;
            this.btnclearc.Click += new System.EventHandler(this.btnclearc_Click);
            // 
            // btnequal
            // 
            this.btnequal.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnequal.Location = new System.Drawing.Point(293, 334);
            this.btnequal.Name = "btnequal";
            this.btnequal.Size = new System.Drawing.Size(40, 23);
            this.btnequal.TabIndex = 7;
            this.btnequal.Text = "=";
            this.btnequal.UseVisualStyleBackColor = true;
            this.btnequal.Click += new System.EventHandler(this.btnequal_Click);
            // 
            // btnone
            // 
            this.btnone.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnone.Location = new System.Drawing.Point(87, 296);
            this.btnone.Name = "btnone";
            this.btnone.Size = new System.Drawing.Size(40, 23);
            this.btnone.TabIndex = 8;
            this.btnone.Text = "1";
            this.btnone.UseVisualStyleBackColor = true;
            this.btnone.Click += new System.EventHandler(this.btnone_Click);
            // 
            // btnmulti
            // 
            this.btnmulti.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmulti.Location = new System.Drawing.Point(293, 261);
            this.btnmulti.Name = "btnmulti";
            this.btnmulti.Size = new System.Drawing.Size(40, 23);
            this.btnmulti.TabIndex = 9;
            this.btnmulti.Text = "*";
            this.btnmulti.UseVisualStyleBackColor = true;
            this.btnmulti.Click += new System.EventHandler(this.button9_Click);
            // 
            // btnsix
            // 
            this.btnsix.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsix.Location = new System.Drawing.Point(200, 261);
            this.btnsix.Name = "btnsix";
            this.btnsix.Size = new System.Drawing.Size(40, 23);
            this.btnsix.TabIndex = 10;
            this.btnsix.Text = "6";
            this.btnsix.UseVisualStyleBackColor = true;
            this.btnsix.Click += new System.EventHandler(this.btnsix_Click);
            // 
            // btnfive
            // 
            this.btnfive.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfive.Location = new System.Drawing.Point(143, 261);
            this.btnfive.Name = "btnfive";
            this.btnfive.Size = new System.Drawing.Size(40, 23);
            this.btnfive.TabIndex = 11;
            this.btnfive.Text = "5";
            this.btnfive.UseVisualStyleBackColor = true;
            this.btnfive.Click += new System.EventHandler(this.btnfive_Click);
            // 
            // btnfour
            // 
            this.btnfour.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfour.Location = new System.Drawing.Point(87, 261);
            this.btnfour.Name = "btnfour";
            this.btnfour.Size = new System.Drawing.Size(40, 23);
            this.btnfour.TabIndex = 12;
            this.btnfour.Text = "4";
            this.btnfour.UseVisualStyleBackColor = true;
            this.btnfour.Click += new System.EventHandler(this.btnfour_Click);
            // 
            // btnnine
            // 
            this.btnnine.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnine.Location = new System.Drawing.Point(200, 222);
            this.btnnine.Name = "btnnine";
            this.btnnine.Size = new System.Drawing.Size(40, 23);
            this.btnnine.TabIndex = 13;
            this.btnnine.Text = "9";
            this.btnnine.UseVisualStyleBackColor = true;
            this.btnnine.Click += new System.EventHandler(this.btnnine_Click);
            // 
            // btndot
            // 
            this.btndot.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndot.Location = new System.Drawing.Point(200, 334);
            this.btndot.Name = "btndot";
            this.btndot.Size = new System.Drawing.Size(40, 23);
            this.btndot.TabIndex = 14;
            this.btndot.Text = ".";
            this.btndot.UseVisualStyleBackColor = true;
            this.btndot.Click += new System.EventHandler(this.btndot_Click);
            // 
            // btnzero
            // 
            this.btnzero.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnzero.Location = new System.Drawing.Point(143, 334);
            this.btnzero.Name = "btnzero";
            this.btnzero.Size = new System.Drawing.Size(40, 23);
            this.btnzero.TabIndex = 15;
            this.btnzero.Text = "0";
            this.btnzero.UseVisualStyleBackColor = true;
            this.btnzero.Click += new System.EventHandler(this.btnzero_Click);
            // 
            // btndivided
            // 
            this.btndivided.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndivided.Location = new System.Drawing.Point(293, 296);
            this.btndivided.Name = "btndivided";
            this.btndivided.Size = new System.Drawing.Size(40, 23);
            this.btndivided.TabIndex = 16;
            this.btndivided.Text = "/";
            this.btndivided.UseVisualStyleBackColor = true;
            this.btndivided.Click += new System.EventHandler(this.btndivided_Click);
            // 
            // btnthree
            // 
            this.btnthree.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnthree.Location = new System.Drawing.Point(200, 296);
            this.btnthree.Name = "btnthree";
            this.btnthree.Size = new System.Drawing.Size(40, 23);
            this.btnthree.TabIndex = 17;
            this.btnthree.Text = "3";
            this.btnthree.UseVisualStyleBackColor = true;
            this.btnthree.Click += new System.EventHandler(this.btnthree_Click);
            // 
            // btntwo
            // 
            this.btntwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntwo.Location = new System.Drawing.Point(143, 296);
            this.btntwo.Name = "btntwo";
            this.btntwo.Size = new System.Drawing.Size(40, 23);
            this.btntwo.TabIndex = 18;
            this.btntwo.Text = "2";
            this.btntwo.UseVisualStyleBackColor = true;
            this.btntwo.Click += new System.EventHandler(this.btntwo_Click);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.BackColor = System.Drawing.SystemColors.Window;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(84, 80);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(0, 16);
            this.label.TabIndex = 20;
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(411, 451);
            this.Controls.Add(this.label);
            this.Controls.Add(this.btntwo);
            this.Controls.Add(this.btnthree);
            this.Controls.Add(this.btndivided);
            this.Controls.Add(this.btnzero);
            this.Controls.Add(this.btndot);
            this.Controls.Add(this.btnnine);
            this.Controls.Add(this.btnfour);
            this.Controls.Add(this.btnfive);
            this.Controls.Add(this.btnsix);
            this.Controls.Add(this.btnmulti);
            this.Controls.Add(this.btnone);
            this.Controls.Add(this.btnequal);
            this.Controls.Add(this.btnclearc);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.btnseven);
            this.Controls.Add(this.btneight);
            this.Controls.Add(this.btnsub);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.resultbox);
            this.Name = "Calculator";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Calculator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox resultbox;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnsub;
        private System.Windows.Forms.Button btneight;
        private System.Windows.Forms.Button btnseven;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnclearc;
        private System.Windows.Forms.Button btnequal;
        private System.Windows.Forms.Button btnone;
        private System.Windows.Forms.Button btnmulti;
        private System.Windows.Forms.Button btnsix;
        private System.Windows.Forms.Button btnfive;
        private System.Windows.Forms.Button btnfour;
        private System.Windows.Forms.Button btnnine;
        private System.Windows.Forms.Button btndot;
        private System.Windows.Forms.Button btnzero;
        private System.Windows.Forms.Button btndivided;
        private System.Windows.Forms.Button btnthree;
        private System.Windows.Forms.Button btntwo;
        private System.Windows.Forms.Label label;
    }
}

